let slideIndex = 1;
let slideshowInterval;
let isPlaying = true;

showSlides(slideIndex);
startSlideshow();

// Function to go to the next or previous slide
function plusSlides(n) {
    showSlides(slideIndex += n);
}

// Function to go to a specific slide
function currentSlide(n) {
    showSlides(slideIndex = n);
}

// Function to display the current slide and hide the others
function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("slide");
    let dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}

// Function to toggle between play and pause
function toggleSlideshow() {
    const pausePlayButton = document.getElementById("pausePlay");
    if (isPlaying) {
        clearInterval(slideshowInterval);
        pausePlayButton.innerHTML = "&#9658;"; // Play symbol (▶)
    } else {
        startSlideshow();
        pausePlayButton.innerHTML = "&#10074;&#10074;"; // Pause symbol (||)
    }
    isPlaying = !isPlaying;
}

// Function to start the slideshow
function startSlideshow() {
    slideshowInterval = setInterval(() => {
        plusSlides(1);
    }, 5000);
}

//Function for Weather 
document.addEventListener('DOMContentLoaded', function () {
    // OpenWeather API - Replace with your own API key
    const apiKey = 'your_openweather_api_key';
    
    // Fetch the visitor's location using IP
    fetch('https://ipapi.co/json/')
        .then(response => response.json())
        .then(locationData => {
            const { city, latitude, longitude } = locationData;

            // Fetch weather data
            fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${apiKey}&units=imperial`)
                .then(response => response.json())
                .then(weatherData => {
                    const temperature = Math.round(weatherData.main.temp);
                    const weatherIcon = weatherData.weather[0].icon;
                    const weatherElement = document.getElementById('weather');
                    weatherElement.innerHTML = `
                        <img src="http://openweathermap.org/img/wn/${weatherIcon}.png" alt="Weather Icon">
                        ${temperature}°F, ${city}
                    `;
                });
        });

    // Function to format time in 12-hour format
    function formatTime(date) {
        let hours = date.getHours();
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const ampm = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        return `${hours}:${minutes} ${ampm}`;
    }

    // Update local time every second
    function updateTime() {
        const date = new Date();
        const timeElement = document.getElementById('local-time');
        timeElement.textContent = `Local Time: ${formatTime(date)}`;
    }

    setInterval(updateTime, 1000); // Update time every second
});
